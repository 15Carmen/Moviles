package com.example.galeria

data class Fotos(var imagenMiniUrl:String)
