package com.example.galeria

interface FotoPulsadaListener {
    fun fotoPulsada(fotos: Fotos){}
}